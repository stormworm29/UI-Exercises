import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import Product from '../../models/product.model';
import { Router } from "@angular/router";

@Component({
  selector: 'app-product-card',
  templateUrl: './product-card.component.html',
  styleUrls: ['./product-card.component.scss']
})
export class ProductCardComponent implements OnInit {
  
  constructor(private router :Router) {
   }

  ngOnInit() {
  }
  @Input() product: Product;

  @Output() clickEmitter = new EventEmitter();

  // isClass = {
  //   "product" : true,
  //   "no-stock" : !this.product.inStock
  // }

  sayHello(productObj: Product) {
    this.clickEmitter.emit(productObj);
    // this.router.navigate(["/productDetails", productObj._id]);
  }
}