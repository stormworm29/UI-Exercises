import { Component, OnInit } from '@angular/core';
import Product from '../../models/product.model';
import { Router } from "@angular/router";
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent implements OnInit {
  products : Product[];
  constructor(private productService: ProductService, private router: Router) { 
    this.productService.getAllProducts().subscribe(data => {
      this.products = data});
  }

  ngOnInit() {
    
  }
  handleHello(product: Product) {
    this.router.navigate(["/productDetails", product._id]);
  }
  searchKey: string = "";
  condition: boolean = true;
  color: string = "red";

}
